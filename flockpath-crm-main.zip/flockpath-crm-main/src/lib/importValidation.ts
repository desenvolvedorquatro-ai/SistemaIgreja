import { supabase } from "@/integrations/supabase/client";

export interface ValidationResult {
  valid: Array<{ row: any; index: number }>;
  invalid: Array<{ row: any; index: number; errors: string[] }>;
  stats: {
    total: number;
    valid: number;
    invalid: number;
  };
}

// Validação de email
export const validateEmail = (email: string): boolean => {
  if (!email) return true; // email opcional
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Validação de telefone
export const validatePhone = (phone: string): boolean => {
  if (!phone) return true; // telefone opcional
  const phoneRegex = /^\(?([0-9]{2})\)?[-. ]?([0-9]{4,5})[-. ]?([0-9]{4})$/;
  return phoneRegex.test(phone.replace(/\s/g, ""));
};

// Converte data de DDMMAAAA ou DD/MM/AAAA ou número serial do Excel para AAAA-MM-DD
export const convertDateFormat = (date: string | number): string | null => {
  if (!date) return null;
  
  // Se for número (serial do Excel)
  if (typeof date === 'number') {
    const excelEpoch = new Date(1899, 11, 30);
    const convertedDate = new Date(excelEpoch.getTime() + date * 86400000);
    const year = convertedDate.getFullYear();
    const month = String(convertedDate.getMonth() + 1).padStart(2, '0');
    const day = String(convertedDate.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  
  const dateStr = String(date).trim();
  
  // Se já está no formato AAAA-MM-DD, retorna como está
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return dateStr;
  }
  
  // Se está no formato DD/MM/AAAA (com barras)
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(dateStr)) {
    const [day, month, year] = dateStr.split('/');
    return `${year}-${month}-${day}`;
  }
  
  // Se está no formato DDMMAAAA (8 dígitos)
  if (/^\d{8}$/.test(dateStr)) {
    const day = dateStr.substring(0, 2);
    const month = dateStr.substring(2, 4);
    const year = dateStr.substring(4, 8);
    return `${year}-${month}-${day}`;
  }
  
  return null;
};

// Validação de data
export const validateDate = (date: string | number): boolean => {
  if (!date) return true; // data opcional
  
  const convertedDate = convertDateFormat(date);
  if (!convertedDate) return false;
  
  const parsedDate = new Date(convertedDate);
  return !isNaN(parsedDate.getTime());
};

// Verificar existência de região
export const validateRegionExists = async (regionName: string): Promise<boolean> => {
  if (!regionName) return true;
  const { data } = await supabase
    .from("regions")
    .select("id")
    .eq("name", regionName)
    .maybeSingle();
  return !!data;
};

// Verificar existência de área
export const validateAreaExists = async (areaName: string): Promise<boolean> => {
  if (!areaName) return true;
  const { data } = await supabase
    .from("areas")
    .select("id")
    .eq("name", areaName)
    .maybeSingle();
  return !!data;
};

// Verificar existência de igreja (com suporte a múltiplas igrejas com mesmo nome)
export const validateChurchExists = async (
  churchName: string,
  areaName?: string,
  regionName?: string
): Promise<boolean> => {
  if (!churchName) return false;
  
  let query = supabase
    .from("churches")
    .select("id, areas(name, regions(name))")
    .eq("name", churchName);
  
  const { data: churches } = await query;
  
  if (!churches || churches.length === 0) return false;
  
  // Se tem área ou região especificada, valida se existe uma igreja compatível
  if (areaName || regionName) {
    return churches.some(church => {
      const areaMatch = !areaName || church.areas?.name === areaName;
      const regionMatch = !regionName || church.areas?.regions?.name === regionName;
      return areaMatch && regionMatch;
    });
  }
  
  return true;
};

// Verificar existência de pastor
export const validatePastorExists = async (email: string): Promise<boolean> => {
  if (!email) return true;
  const { data } = await supabase
    .from("profiles")
    .select("id")
    .eq("email", email)
    .maybeSingle();
  return !!data;
};

// Verificar existência de grupo de assistência
export const validateAssistanceGroupExists = async (
  groupName: string,
  churchId: string
): Promise<boolean> => {
  if (!groupName) return true;
  const { data } = await supabase
    .from("assistance_groups")
    .select("id")
    .eq("name", groupName)
    .eq("church_id", churchId)
    .maybeSingle();
  return !!data;
};

// Validação para Regiões
const validateRegiao = async (row: any): Promise<string[]> => {
  const errors: string[] = [];

  if (!row.nome || String(row.nome).trim() === "") {
    errors.push("Nome é obrigatório");
  }

  if (row.pastor_email) {
    if (!validateEmail(row.pastor_email)) {
      errors.push("Email do pastor inválido");
    } else {
      const pastorExists = await validatePastorExists(row.pastor_email);
      if (!pastorExists) {
        errors.push("Pastor não encontrado no sistema");
      }
    }
  }

  return errors;
};

// Validação para Áreas
const validateArea = async (row: any): Promise<string[]> => {
  const errors: string[] = [];

  if (!row.nome || String(row.nome).trim() === "") {
    errors.push("Nome é obrigatório");
  }

  if (!row.nome_regiao || String(row.nome_regiao).trim() === "") {
    errors.push("Nome da região é obrigatório");
  } else {
    const regionExists = await validateRegionExists(row.nome_regiao);
    if (!regionExists) {
      errors.push(`Região '${row.nome_regiao}' não encontrada`);
    }
  }

  if (row.pastor_email) {
    if (!validateEmail(row.pastor_email)) {
      errors.push("Email do pastor inválido");
    } else {
      const pastorExists = await validatePastorExists(row.pastor_email);
      if (!pastorExists) {
        errors.push("Pastor não encontrado no sistema");
      }
    }
  }

  return errors;
};

// Validação para Igrejas
const validateIgreja = async (row: any): Promise<string[]> => {
  const errors: string[] = [];

  if (!row.nome || String(row.nome).trim() === "") {
    errors.push("Nome é obrigatório");
  }

  if (row.email && !validateEmail(row.email)) {
    errors.push("Email inválido");
  }

  if (row.telefone && !validatePhone(row.telefone)) {
    errors.push("Telefone inválido");
  }

  if (row.nome_regiao) {
    const regionExists = await validateRegionExists(row.nome_regiao);
    if (!regionExists) {
      errors.push(`Região '${row.nome_regiao}' não encontrada`);
    }
  }

  if (row.nome_area) {
    const areaExists = await validateAreaExists(row.nome_area);
    if (!areaExists) {
      errors.push(`Área '${row.nome_area}' não encontrada`);
    }
  }

  if (row.pastor_email) {
    if (!validateEmail(row.pastor_email)) {
      errors.push("Email do pastor inválido");
    } else {
      const pastorExists = await validatePastorExists(row.pastor_email);
      if (!pastorExists) {
        errors.push("Pastor não encontrado no sistema");
      }
    }
  }

  return errors;
};

// Validação para Visitantes
const validateVisitante = async (row: any): Promise<string[]> => {
  const errors: string[] = [];

  if (!row.nome || String(row.nome).trim() === "") {
    errors.push("Nome é obrigatório");
  }

  if (!row.nome_igreja || String(row.nome_igreja).trim() === "") {
    errors.push("Nome da igreja é obrigatório");
  } else {
    const churchExists = await validateChurchExists(
      row.nome_igreja,
      row.nome_area,
      row.nome_regiao
    );
    if (!churchExists) {
      errors.push(`Igreja '${row.nome_igreja}' não encontrada`);
    }
  }

  if (row.email && !validateEmail(row.email)) {
    errors.push("Email inválido");
  }

  if (row.telefone && !validatePhone(row.telefone)) {
    errors.push("Telefone inválido");
  }

  if (row.data_visita && !validateDate(row.data_visita)) {
    errors.push("Data de visita inválida (use formato DD/MM/AAAA, DDMMAAAA ou AAAA-MM-DD)");
  }

  if (row.data_nascimento && !validateDate(row.data_nascimento)) {
    errors.push("Data de nascimento inválida (use formato DD/MM/AAAA, DDMMAAAA ou AAAA-MM-DD)");
  }

  if (row.data_batismo && !validateDate(row.data_batismo)) {
    errors.push("Data de batismo inválida (use formato DD/MM/AAAA, DDMMAAAA ou AAAA-MM-DD)");
  }

  // Validar status se fornecido
  if (row.status && !['interessado', 'visitante', 'visitante_frequente', 'candidato_batismo', 'membro'].includes(row.status)) {
    errors.push("Status inválido. Use: interessado, visitante, visitante_frequente, candidato_batismo ou membro");
  }

  // Validar categoria se fornecido
  if (row.categoria && !['crianca', 'intermediario', 'adolescente', 'jovem', 'senhora', 'varao', 'idoso'].includes(row.categoria)) {
    errors.push("Categoria inválida. Use: crianca, intermediario, adolescente, jovem, senhora, varao ou idoso");
  }

  // Validar resgate se fornecido
  if (row.resgate && !['Sim', 'Não', 'sim', 'não'].includes(row.resgate)) {
    errors.push("Resgate inválido. Use: Sim ou Não");
  }

  return errors;
};

// Função principal de validação
export const validateImportData = async (
  jsonData: any[],
  type: string
): Promise<ValidationResult> => {
  const valid: Array<{ row: any; index: number }> = [];
  const invalid: Array<{ row: any; index: number; errors: string[] }> = [];

  for (let i = 0; i < jsonData.length; i++) {
    const row = jsonData[i];
    let errors: string[] = [];

    switch (type) {
      case "regioes":
        errors = await validateRegiao(row);
        break;
      case "areas":
        errors = await validateArea(row);
        break;
      case "igrejas":
        errors = await validateIgreja(row);
        break;
      case "visitantes":
        errors = await validateVisitante(row);
        break;
    }

    if (errors.length === 0) {
      valid.push({ row, index: i });
    } else {
      invalid.push({ row, index: i, errors });
    }
  }

  return {
    valid,
    invalid,
    stats: {
      total: jsonData.length,
      valid: valid.length,
      invalid: invalid.length,
    },
  };
};
